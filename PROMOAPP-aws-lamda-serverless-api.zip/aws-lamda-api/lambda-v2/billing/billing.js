const awsRequestHelper = require('./../../lambda/common/awsRequestHelper');
module.exports.handler = async function (event, context, callback) {
    let resource = event.requestContext.resourcePath;
    switch(resource){
        case '/billing/{id}/billingHistory':
            const billingHistoryHandler = require('./getBillingHistory');
            return await billingHistoryHandler.handler(event,context,callback);
        case '/user/myPlans':
            const myPlansHandler = require('./myPlans');
            return await myPlansHandler.handler(event,context,callback);
        case '/user/getGatewayId' :
            const getGatewayIdHandler = require('./getGatewayId');
            return await getGatewayIdHandler.handler(event,context,callback);
        case '/users/{id}/card':
            const cardHandler = require('./addcard');
            return await cardHandler.handler(event,context,callback);
    }
    return awsRequestHelper.respondWithSimpleMessage(500,'Unable to serve request.Contact administrator');
}