const stripe = require("stripe")(process.env.STRIPE_KEY);//this key should be the private key
const awsRequestHelper = require('./../../lambda/common/awsRequestHelper');
const Joi = require('joi');
const DBM = require('../common/mysqlmanager');
const DBManager = new DBM();
const utils = require('../common/utils')

const validate = function (body) {
    const schema = Joi.object().keys({
        gateway_id: Joi.string().required(),
        source: Joi.string().required()
        });
    return new Promise((resolve, reject) => {

        Joi.validate(body, schema, {
            abortEarly: false
        }, function (err, value) {

            if (err) {
                reject({status_code:400,message:'Invalid input'});
            }
            else {
                resolve(value);
            }

        });

    });
    
}

const addCard = function(apiData){
    console.log(stripe.customers.object);
    return stripe.customers.update(
        apiData.gateway_id,
        {
          source: apiData.source,
        });
};

// This function is used to update payment gateway in QB
const updatePaymentGateway = async (apiData, user) => {
    let updateUserPaymentBody = {
    };

    if ('source' in apiData && apiData.source) {
        // Get the token details for last 4 
        let tokenDetails = await stripe.tokens.retrieve(apiData.source);
        console.log('tokenDetails',tokenDetails);
        if (tokenDetails && 'card' in tokenDetails && tokenDetails.card) {
            updateUserPaymentBody.last4 = tokenDetails.card.last4;
        }
    }
console.log(updateUserPaymentBody)
    // Update if qb id for UserPaymentGateway Table is given
    let whereQry = { _user_id: user['id'], id: apiData.id }
        console.log('Updating ',apiData.id, updateUserPaymentBody);
        let response = await DBManager.dataUpdate('user_payment_gateway', updateUserPaymentBody, whereQry);
        console.log(response);
};

module.exports.handler = async function (event, context, callback) {
    try{
        let user = await utils.verifyUser(event.headers.Authorization);
        let apiData = JSON.parse(event.body);

        await validate(apiData);
        await addCard(apiData);
        await updatePaymentGateway(apiData, user);
        return awsRequestHelper.respondWithCodeOnly(204);
    }catch(err){
        console.log('error in updating card is::',err);
        if(err && err.status_code == 400){
            return awsRequestHelper.respondWithSimpleMessage(400, err.message);
        }else{
            return awsRequestHelper.respondWithSimpleMessage(500, err.message);
        }
    }
}